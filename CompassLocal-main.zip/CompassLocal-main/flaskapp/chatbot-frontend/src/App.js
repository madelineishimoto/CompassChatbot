import React from 'react';
import ChatComponent from './ChatComponent'; // Adjust the path if necessary

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <ChatComponent />
      </header>
    </div>
  );
}

export default App;
